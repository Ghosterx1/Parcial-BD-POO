/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Usuario;
import java.sql.*;
import javax.swing.JOptionPane;

public class UsuarioDao {
    private Connection con;

    public UsuarioDao(Connection con) {
        this.con = con;
    }

    // Método para registrar un usuario
    public boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuario (nombre_usuario, contrasena) VALUES (?, ?)";
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, usuario.getNombreUsuario());
            pst.setString(2, usuario.getContrasena());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuario registrado correctamente");
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

    // Método para validar el login
    public boolean validarLogin(String nombreUsuario, String contrasena) {
        String sql = "SELECT * FROM usuario WHERE nombre_usuario=? AND contrasena=?";
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, nombreUsuario);
            pst.setString(2, contrasena);
            ResultSet rs = pst.executeQuery();
            return rs.next(); // Retorna true si encuentra una coincidencia
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al validar login: " + e.getMessage());
            return false;
        }
    }
}
