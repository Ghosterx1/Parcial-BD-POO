package Vista;

/**
 *
 * @author juank
 */
public class Main {
    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
    }
}
